# Bluemercury-Clone

Kamlesh Bhatt -> Home Page <br />
Tilak Ram -> Navbar, Footer, Payment Page <br />
Aravind Macherla -> Product Page <br />
Anwar Rizwan -> Login/Signup Page <br />
Bharatveer Singh -> Cart/Wishlist Page <br />